
// const readMoreBtn=document.querySelector(".read-more-btn");
// const one=document.querySelector(".one");

// readMoreBtn.addEventListener('click',(e)=>{
//     one.classList.toggle("show-more");
//     if(readMoreBtn.innerText === "load more"){
//         readMoreBtn.innerText="load less";
//     }else{
//         readMoreBtn.innerText="load more";
//     }
// })


// ----------------------jquery-------------------
// $(document).ready(function(){
//     shareMenu();
// })

// function shareMenu(){
//     $('.image-container .more:first-child').addClass('active');
//     $('.image-container .more:first-child').find('.share-menu').toggle();
//     $('.share').click(function(){
//         $(this).closest('.image-container .more').toggleClass('active');
//         $(this).closest('.image-container .more').find('.share-menu').stop().toggle();

//     })
// }





var settingsmenu = document.querySelector(".settings-menu");
function settingsMenu() {
    settingsmenu.classList.toggle("settings-menu-height");
}

// const more=document.querySelectorAll('.more');

// function activeLink(){
//     more.forEach((item)=>
//     item.classList.remove('active'));
//     this.classList.add('active');

    
// }
// more.forEach((item)=>
// item.addEventListener('click',activeLink));



function shareMenu(commentId1) {
    var sharemenu = document.querySelector("[data-comment1='"+commentId1+"']");
    sharemenu.classList.toggle("share-menu-height");
}

function commentMenu(commentId2) {
    var commentmenu = document.querySelector("[data-comment2='"+commentId2+"']");
    commentmenu.classList.toggle("comment-menu-height");
}


let loadMoreBtn = document.querySelector('#load-more');
let currentItem = 2;
loadMoreBtn.onclick = () => {
    let boxes = [...document.querySelectorAll(".image-container .more")];
    for (var i = currentItem; i < currentItem + 2; i++) {
        boxes[i].style.display = "inline";

    }
    currentItem += 2;
    if (currentItem >= boxes.length) {
        loadMoreBtn.style.display = 'none';
    }
}



var a;

function showHide() {
    if (a == 1) {
        document.getElementById("i").style.display = "inline-block";
        return a = 0;
    }
    else {
        document.getElementById("i").style.display = "none";
        return a = 1;
    }
}

var b;
function show_Hide() {
    if (b == 1) {
        document.getElementById("chat").style.display = "inline-block";
        return b = 0;
    }
    else {
        document.getElementById("chat").style.display = "none";
        return b = 1;
    }
}

var c;

function showHide1() {
    if (c == 1) {
        document.getElementById("info").style.display = "none";
        return c = 0;
    }
    else {
        document.getElementById("info").style.display = "inline-block";
        return c = 1;
    }
}

var d;

function showHide2() {
    if (d == 1) {
        document.getElementById("info1").style.display = "none";
        return d = 0;
    }
    else {
        document.getElementById("info1").style.display = "inline-block";
        return d = 1;
    }
}

var e;
function booking1() {
    if (e == 1) {
        document.getElementById("booking1").style.display = "none";
        return e = 0;
    }
    else {
        document.getElementById("booking1").style.display = "inline-block";
        return e = 1;
    }
}
var f;
function booking2() {
    if (f == 1) {
        document.getElementById("booking2").style.display = "none";
        return f = 0;
    }
    else {
        document.getElementById("booking2").style.display = "inline-block";
        return f = 1;
    }
}

